// Localização: (app)/constants/Colors.ts

// Paleta escura inspirada na tela de acompanhamento
const primary = '#2E7D32'; // verde
const yellow = '#FFD600';
const background = '#121212';
const card = '#232323';
const cardAlt = '#263238';
const text = '#fff';
const textSecondary = '#B0B0B0';
const border = '#333';
const destructive = '#E53935';

export default {
  text,
  textSecondary,
  background,
  card,
  cardAlt,
  tint: primary,
  icon: textSecondary,
  tabIconDefault: textSecondary,
  tabIconSelected: yellow,
  destructive,
  lightGray: '#181C24',
  yellow,
  border,
};