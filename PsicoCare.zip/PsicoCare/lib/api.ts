/**
 * Criar acompanhamento diário
 */
export const criarAcompanhamento = async (
  dados: { texto: string; qualidade_sono: number; humor: string; data_hora?: string },
  token: string
): Promise<any> => {
  return await apiFetch('/acompanhamentos', 'POST', dados, token);
};

/**
 * Buscar acompanhamentos do usuário autenticado
 */
export const getAcompanhamentos = async (token: string): Promise<any[]> => {
  return await getComToken('/acompanhamentos', token);
};
/**
 * Buscar dados do usuário pelo ID
 */
export const getUsuarioById = async (id: number, token: string): Promise<any> => {
  return await getComToken(`/usuarios/${id}`, token);
};
/**
 * Buscar agendamentos do usuário autenticado
 */
export const getAgendamentosUsuario = async (usuarioId: number, token: string): Promise<any[]> => {
  return await getComToken(`/agendamentos?usuarioId=${usuarioId}`, token);
};
/**
 * Atualização de usuário
 */
export const updateUsuario = async (id: number, dados: { nome: string; email: string }, token: string): Promise<any> => {
  return await apiFetch(`/usuarios/${id}`, 'PUT', dados, token);
};

const BASE_URL = 'http://localhost:3333';


interface LoginResponse {
  token: string;
  nome: string;
  email: string;
}

interface LoginPayload {
  email: string;
  senha: string;
}

interface UsuarioCadastro {
  nome: string;
  email: string;
  senha: string;
  telefone: string;
  nascimento: string;
}

/**
 * Função genérica para requisições à API
 */
const apiFetch = async (
  endpoint: string,
  method: 'GET' | 'POST' | 'PUT' | 'DELETE' = 'GET',
  body?: object,
  token?: string
): Promise<any> => {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const response = await fetch(`${BASE_URL}${endpoint}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });

  if (!response.ok) {
    const erro = await response.json();
    throw new Error(erro.erro || 'Erro na requisição');
  }

  return await response.json();
};

/**
 * Login de usuário
 */
export const login = async ({ email, senha }: LoginPayload): Promise<LoginResponse> => {
  return await apiFetch('/auth/login', 'POST', { email, senha });
};

/**
 * Cadastro de novo usuário
 */
export const cadastrarUsuario = async (dados: UsuarioCadastro): Promise<any> => {
  return await apiFetch('/usuarios', 'POST', dados);
};

/**
 * GET com autenticação
 */
export const getComToken = async (endpoint: string, token: string): Promise<any> => {
  return await apiFetch(endpoint, 'GET', undefined, token);
};
