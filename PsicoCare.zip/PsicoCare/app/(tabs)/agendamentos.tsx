// Localização: (app)/agendamentos.tsx



import { useRouter } from 'expo-router';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, ActivityIndicator, TextInput } from 'react-native';
import { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { getAgendamentosUsuario, criarAcompanhamento, getAcompanhamentos } from '../../lib/api';


export default function Agendamentos() {
  const router = useRouter();
  const { user, token } = useAuth();
  const [agendamentos, setAgendamentos] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Estados para acompanhamento diário
  const [acompanhamentos, setAcompanhamentos] = useState<any[]>([]);
  const [loadingAcompanhamento, setLoadingAcompanhamento] = useState(false);
  const [textoAcompanhamento, setTextoAcompanhamento] = useState('');
  const [qualidadeSono, setQualidadeSono] = useState(0); // 1 a 5
  const [humor, setHumor] = useState(''); // emoji

  // Opções de humor (texto)
  const humores = [
    { label: 'Estável', value: 'Estável' },
    { label: 'Ansioso', value: 'Ansioso' },
    { label: 'Triste', value: 'Triste' },
    { label: 'Irritado', value: 'Irritado' },
    { label: 'Outro', value: 'Outro' },
  ];
  useEffect(() => {
    const fetchAgendamentos = async () => {
      if (!user || !token) return;
      setLoading(true);
      try {
        const data = await getAgendamentosUsuario(user.id, token);
        setAgendamentos(data);
      } catch (e) {
        setAgendamentos([]);
      } finally {
        setLoading(false);
      }
    };
    fetchAgendamentos();
  }, [user, token]);


  // Função para agendar uma data aleatória (apenas para teste)
  const handleAgendarAleatorio = () => {
    const dias = Math.floor(Math.random() * 30) + 1;
    const data = new Date();
    data.setDate(data.getDate() + dias);
    const dataStr = data.toLocaleDateString('pt-BR');
    const novo = {
      id: Math.random().toString(36).substring(2),
      data: dataStr,
      descricao: 'Sessão agendada (teste)',
    };
    setAgendamentos([novo, ...agendamentos]);
  };

  // Função para salvar acompanhamento diário
  const handleSalvarAcompanhamento = async () => {
    if (!textoAcompanhamento && !qualidadeSono && !humor) return;
    setLoadingAcompanhamento(true);
    try {
      await criarAcompanhamento({
        texto: textoAcompanhamento,
        qualidade_sono: qualidadeSono,
        humor,
      }, token);
      await fetchAcompanhamentos();
      setTextoAcompanhamento('');
      setQualidadeSono(0);
      setHumor('');
    } catch (e) {
      // Pode exibir um alerta de erro se quiser
    }
    setLoadingAcompanhamento(false);
  };

  const fetchAcompanhamentos = async () => {
    if (!token) return;
    setLoadingAcompanhamento(true);
    try {
      const data = await getAcompanhamentos(token);
      setAcompanhamentos(data.map((a: any) => ({
        ...a,
        dataHora: a.data_hora ? new Date(a.data_hora).toLocaleString('pt-BR') : '',
        sono: a.qualidade_sono,
      })));
    } catch (e) {
      setAcompanhamentos([]);
    }
    setLoadingAcompanhamento(false);
  };

  useEffect(() => {
    fetchAcompanhamentos();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token]);

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.scrollContent}
    >
      <Text style={styles.title}>Os Seus Agendamentos</Text>
      <TouchableOpacity style={[styles.button, { backgroundColor: '#1976D2', marginBottom: 12 }]} onPress={handleAgendarAleatorio}>
        <Text style={styles.buttonText}>Agendar data aleatória (teste)</Text>
      </TouchableOpacity>
      {loading ? (
        <ActivityIndicator color="#fff" size="large" style={{ marginTop: 32 }} />
      ) : agendamentos.length === 0 ? (
        <Text style={{ color: '#fff', marginTop: 24 }}>Nenhum agendamento encontrado.</Text>
      ) : (
        agendamentos.map((ag, idx) => (
          <View style={styles.card} key={ag.id || idx}>
            <Text style={styles.date}>{ag.data ? ag.data : 'Data não informada'}</Text>
            <Text style={styles.desc}>{ag.descricao || 'Sessão agendada'}</Text>
          </View>
        ))
      )}

      {/* Seção de acompanhamento diário */}
      <Text style={[styles.title, { marginTop: 32 }]}>Acompanhamento Diário</Text>
      <View style={styles.acompanhamentoCard}>
        <Text style={styles.label}>Observações do dia</Text>
        <TextInput
          style={styles.inputArea}
          placeholder="Descreva sintomas, eventos ou observações clínicas."
          placeholderTextColor="#aaa"
          value={textoAcompanhamento}
          onChangeText={setTextoAcompanhamento}
          multiline
        />
        <Text style={styles.label}>Qualidade do sono (1-5):</Text>
        <TextInput
          style={styles.inputArea}
          placeholder="Ex: 3"
          placeholderTextColor="#aaa"
          value={qualidadeSono ? String(qualidadeSono) : ''}
          onChangeText={v => setQualidadeSono(Number(v.replace(/[^1-5]/g, '')))}
          keyboardType="numeric"
          maxLength={1}
        />
        <Text style={styles.label}>Estado emocional:</Text>
        <View style={styles.humorRow}>
          {humores.map((h) => (
            <TouchableOpacity
              key={h.value}
              style={[styles.humorBtn, humor === h.value && styles.humorBtnSelected]}
              onPress={() => setHumor(h.value)}
            >
              <Text style={{ fontSize: 15 }}>{h.label}</Text>
            </TouchableOpacity>
          ))}
        </View>
        <TouchableOpacity style={[styles.button, { marginTop: 12 }]} onPress={handleSalvarAcompanhamento}>
          <Text style={styles.buttonText}>Salvar registro</Text>
        </TouchableOpacity>
      </View>

      {loadingAcompanhamento ? (
        <ActivityIndicator color="#FFD600" style={{ marginTop: 16 }} />
      ) : acompanhamentos.length > 0 && (
        <View style={{ marginTop: 18 }}>
          <Text style={{ color: '#fff', fontWeight: 'bold', marginBottom: 8 }}>Histórico de acompanhamentos:</Text>
          {acompanhamentos.map((a) => (
            <View key={a.id} style={[styles.card, { backgroundColor: '#263238', borderLeftWidth: 5, borderLeftColor: '#FFD600' }]}> 
              <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 4 }}>
                <Text style={{ color: '#fff', fontWeight: 'bold', fontSize: 13, marginRight: 8 }}>{a.dataHora}</Text>
                <Text style={{ color: '#B0B0B0', fontSize: 13, marginRight: 8 }}>Sono: {a.sono || '-'}</Text>
                <Text style={{ color: '#B0B0B0', fontSize: 13 }}>Humor: {a.humor || '-'}</Text>
              </View>
              <Text style={{ color: '#fff', marginTop: 2 }}>{a.texto}</Text>
            </View>
          ))}
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#121212', // Cor de fundo escura, como na sua imagem
  },
  // Adicione este novo estilo 👇
  scrollContent: {
    padding: 24,
    paddingBottom: 100, // <--- A MÁGICA ACONTECE AQUI
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 16,
    color: '#FFFFFF',
  },
  card: {
    padding: 16,
    borderRadius: 10,
    backgroundColor: '#1E1E1E', // Cor do card mais escura
    marginBottom: 12,
    borderColor: '#2F2F2F',
    borderWidth: 1,
  },
  date: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  desc: {
    fontSize: 14,
    marginTop: 4,
    color: '#B0B0B0',
  },
  button: {
    marginTop: 24,
    backgroundColor: '#2E7D32', // Usando a cor verde da aba ativa
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  inputArea: {
    backgroundColor: '#232323',
    color: '#fff',
    borderRadius: 8,
    padding: 12,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#333',
    fontSize: 15,
    minHeight: 60,
    textAlignVertical: 'top',
  },
  acompanhamentoCard: {
    backgroundColor: '#181C24',
    borderRadius: 12,
    padding: 16,
    marginBottom: 18,
    borderWidth: 1,
    borderColor: '#222',
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 2,
  },
  label: {
    color: '#fff',
    fontWeight: 'bold',
    marginBottom: 6,
    marginTop: 6,
  },
  starsRow: {
    flexDirection: 'row',
    marginBottom: 10,
    marginTop: 2,
  },
  humorRow: {
    flexDirection: 'row',
    marginBottom: 10,
    marginTop: 2,
    gap: 8,
  },
  humorBtn: {
    backgroundColor: '#232323',
    borderRadius: 8,
    padding: 6,
    marginHorizontal: 2,
    borderWidth: 1,
    borderColor: '#333',
  },
  humorBtnSelected: {
    backgroundColor: '#FFD60033',
    borderColor: '#FFD600',
  },
});