
import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Modal, ScrollView } from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import Colors from '../../constants/Colors';
import { useAuth } from '../contexts/AuthContext';

export default function Perfil() {
  const router = useRouter();
  const { user, signOut } = useAuth();
  const [modalVisible, setModalVisible] = useState(false);

  const handleLogout = async () => {
    setModalVisible(false);
    await signOut();
    router.replace('/login');
    setTimeout(() => {
      if (typeof window !== 'undefined') {
        window.location.reload();
      }
    }, 100);
  };

  if (!user) {
    return (
      <View style={styles.loadingContainer}>
        <Text>A carregar perfil...</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.headerContainer}>
        <Ionicons name="person-circle" size={80} color={Colors.tint} />
        <Text style={styles.userName}>{user.nome}</Text>
        <Text style={styles.userEmail}>{user.email}</Text>
      </View>

      <View style={styles.menuContainer}>
        <TouchableOpacity style={styles.listItem} onPress={() => router.push('/edit-profile')}>
          <Ionicons name="person-outline" size={24} color={Colors.tint} />
          <Text style={styles.listItemText}>Editar Perfil</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.listItem} onPress={() => setModalVisible(true)}>
          <Ionicons name="log-out-outline" size={24} color={Colors.destructive} />
          <Text style={[styles.listItemText, { color: Colors.destructive }]}>Sair</Text>
        </TouchableOpacity>
        <Modal
          visible={modalVisible}
          transparent
          animationType="fade"
          onRequestClose={() => setModalVisible(false)}
        >
          <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.7)', justifyContent: 'center', alignItems: 'center' }}>
            <View style={{ backgroundColor: Colors.card, borderRadius: 16, padding: 28, width: 320, alignItems: 'center', borderWidth: 1, borderColor: Colors.border }}>
              <Text style={{ fontSize: 18, fontWeight: 'bold', marginBottom: 12, color: Colors.text }}>Terminar Sessão</Text>
              <Text style={{ fontSize: 16, color: Colors.textSecondary, marginBottom: 24, textAlign: 'center' }}>
                Tem certeza que deseja sair da sua conta?
              </Text>
              <View style={{ flexDirection: 'row', gap: 12 }}>
                <TouchableOpacity onPress={() => setModalVisible(false)} style={{ padding: 12, borderRadius: 8, backgroundColor: Colors.background, marginRight: 8, borderWidth: 1, borderColor: Colors.border }}>
                  <Text style={{ color: Colors.text }}>Cancelar</Text>
                </TouchableOpacity>
                <TouchableOpacity onPress={handleLogout} style={{ padding: 12, borderRadius: 8, backgroundColor: Colors.destructive }}>
                  <Text style={{ color: '#fff', fontWeight: 'bold' }}>Sair</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </Modal>
        {/* Botão de logout direto para teste */}
        <TouchableOpacity style={[styles.listItem, { backgroundColor: '#ffdddd' }]} onPress={async () => {
          await signOut();
          router.replace('/login');
          setTimeout(() => {
            if (typeof window !== 'undefined') {
              window.location.reload();
            }
          }, 100);
        }}>
          <Ionicons name="exit-outline" size={24} color={Colors.destructive} />
          <Text style={[styles.listItemText, { color: Colors.destructive }]}>Logout Direto (Teste)</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerContainer: {
    backgroundColor: Colors.card,
    paddingVertical: 30,
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  userName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: Colors.text,
    marginTop: 10,
  },
  userEmail: {
    fontSize: 16,
    color: Colors.icon,
    marginTop: 5,
  },
  menuContainer: {
    marginTop: 30,
  },
  listItem: {
    backgroundColor: Colors.card,
    paddingHorizontal: 20,
    paddingVertical: 15,
    flexDirection: 'row',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  listItemText: {
    flex: 1,
    marginLeft: 15,
    fontSize: 16,
    color: Colors.text,
  },
});