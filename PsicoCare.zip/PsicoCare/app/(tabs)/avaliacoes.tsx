// Localização: (app)/(tabs)/avaliacoes.tsx

import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, TextInput, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import Colors from '../../constants/Colors';

// Tipo para as opções de humor e sono
type MoodOption = 'Feliz' | 'Neutro' | 'Triste' | 'Ansioso';
type SleepOption = 1 | 2 | 3 | 4 | 5;

export default function AcompanhamentoScreen() {
  const [mood, setMood] = useState<MoodOption | null>(null);
  const [sleep, setSleep] = useState<SleepOption | null>(null);
  const [sentimentos, setSentimentos] = useState('');

  const handleSave = () => {
    if (!mood || !sleep) {
      Alert.alert("Campos em falta", "Por favor, selecione o seu humor e a qualidade do seu sono.");
      return;
    }
    // Lógica para enviar os dados para a sua API
    console.log({
      humor: mood,
      sono: `Nota ${sleep}`,
      sentimentos,
    });
    Alert.alert("Registo Guardado", "O seu acompanhamento foi guardado com sucesso!");
    // Limpar o formulário
    setMood(null);
    setSleep(null);
    setSentimentos('');
  };

  return (
    <ScrollView 
      style={styles.container}
      contentContainerStyle={{ paddingBottom: 100 }} // Espaço para o menu
    >
      <Text style={styles.title}>Acompanhamento Diário</Text>
      <Text style={styles.subtitle}>Como se está a sentir hoje?</Text>

      {/* Seletor de Humor */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Humor</Text>
        <View style={styles.optionsContainer}>
          <TouchableOpacity onPress={() => setMood('Feliz')} style={[styles.moodOption, mood === 'Feliz' && styles.moodOptionSelected]}>
            <Text style={styles.emoji}>😊</Text>
            <Text style={styles.optionText}>Feliz</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => setMood('Neutro')} style={[styles.moodOption, mood === 'Neutro' && styles.moodOptionSelected]}>
            <Text style={styles.emoji}>😐</Text>
            <Text style={styles.optionText}>Neutro</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => setMood('Triste')} style={[styles.moodOption, mood === 'Triste' && styles.moodOptionSelected]}>
            <Text style={styles.emoji}>😔</Text>
            <Text style={styles.optionText}>Triste</Text>
          </TouchableOpacity>
           <TouchableOpacity onPress={() => setMood('Ansioso')} style={[styles.moodOption, mood === 'Ansioso' && styles.moodOptionSelected]}>
            <Text style={styles.emoji}>😟</Text>
            <Text style={styles.optionText}>Ansioso</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Seletor de Sono */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Qualidade do Sono</Text>
        <View style={styles.optionsContainer}>
          {[1, 2, 3, 4, 5].map((star) => (
            <TouchableOpacity key={star} onPress={() => setSleep(star as SleepOption)}>
              <Ionicons name={sleep && sleep >= star ? "star" : "star-outline"} size={32} color="#FFC107" />
            </TouchableOpacity>
          ))}
        </View>
      </View>
      
      {/* Campo de Sentimentos */}
      <View style={styles.section}>
         <Text style={styles.sectionTitle}>Descreva os seus sentimentos</Text>
         <TextInput
            style={styles.textArea}
            multiline
            numberOfLines={4}
            placeholder="Escreva aqui como se sentiu hoje..."
            value={sentimentos}
            onChangeText={setSentimentos}
         />
      </View>
      
      {/* Botão de Guardar */}
      <TouchableOpacity style={styles.button} onPress={handleSave}>
        <Text style={styles.buttonText}>Guardar Registo</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.lightGray,
    padding: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: Colors.text,
  },
  subtitle: {
    fontSize: 16,
    color: Colors.icon,
    marginBottom: 30,
  },
  section: {
    marginBottom: 25,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.text,
    marginBottom: 15,
  },
  optionsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
  },
  moodOption: {
    alignItems: 'center',
    padding: 10,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#E5E7EB',
    backgroundColor: Colors.background,
    width: 80,
  },
  moodOptionSelected: {
    borderColor: Colors.tint,
    backgroundColor: '#E0F7FA', // Um azul muito claro para indicar seleção
  },
  emoji: {
    fontSize: 30,
  },
  optionText: {
    marginTop: 5,
    color: Colors.text,
  },
  textArea: {
    backgroundColor: Colors.background,
    padding: 15,
    borderRadius: 10,
    fontSize: 16,
    borderWidth: 1,
    borderColor: '#E5E7EB',
    textAlignVertical: 'top',
    height: 120,
  },
  button: {
    backgroundColor: Colors.tint,
    padding: 16,
    borderRadius: 15,
    alignItems: 'center',
    marginTop: 20,
  },
  buttonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 16,
  },
});