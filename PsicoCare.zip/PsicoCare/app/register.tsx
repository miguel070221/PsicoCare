// Localização: (app)/register.tsx

import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import { useRouter } from 'expo-router';
import Colors from '../constants/Colors';

type UserType = 'paciente' | 'psicologo';

export default function RegisterScreen() {
  const router = useRouter();
  const [userType, setUserType] = useState<UserType>('paciente');
  const [crp, setCrp] = useState('');

  // Adicione aqui os outros estados para nome, email, senha, etc.

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Criar Conta</Text>

      {/* Seletor de Tipo de Utilizador */}
      <View style={styles.userTypeSelector}>
        <TouchableOpacity
          style={[styles.userTypeButton, userType === 'paciente' && styles.userTypeButtonActive]}
          onPress={() => setUserType('paciente')}
        >
          <Text style={[styles.userTypeText, userType === 'paciente' && styles.userTypeTextActive]}>Sou Paciente</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.userTypeButton, userType === 'psicologo' && styles.userTypeButtonActive]}
          onPress={() => setUserType('psicologo')}
        >
          <Text style={[styles.userTypeText, userType === 'psicologo' && styles.userTypeTextActive]}>Sou Psicólogo</Text>
        </TouchableOpacity>
      </View>

      <TextInput style={styles.input} placeholder="Nome Completo" />
      <TextInput style={styles.input} placeholder="Email" keyboardType="email-address" />
      <TextInput style={styles.input} placeholder="Senha" secureTextEntry />
      <TextInput style={styles.input} placeholder="Telefone" keyboardType="phone-pad" />
      <TextInput style={styles.input} placeholder="Data de nascimento (AAAA-MM-DD)" />

      {/* Campo de CRP Condicional */}
      {userType === 'psicologo' && (
        <TextInput
          style={styles.input}
          placeholder="Número do CRP"
          value={crp}
          onChangeText={setCrp}
        />
      )}

      <TouchableOpacity style={styles.button}>
        <Text style={styles.buttonText}>Cadastrar</Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => router.push('/login')}>
        <Text style={styles.linkText}>Já tenho conta</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
    padding: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: Colors.text,
    textAlign: 'center',
    marginBottom: 30,
    marginTop: 40,
  },
  userTypeSelector: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 20,
    backgroundColor: Colors.card,
    borderRadius: 10,
    padding: 4,
  },
  userTypeButton: {
    flex: 1,
    padding: 10,
    borderRadius: 8,
  },
  userTypeButtonActive: {
    backgroundColor: Colors.yellow,
  },
  userTypeText: {
    textAlign: 'center',
    fontWeight: 'bold',
    color: Colors.textSecondary,
  },
  userTypeTextActive: {
    color: Colors.background,
  },
  input: {
    backgroundColor: Colors.card,
    color: Colors.text,
    padding: 15,
    borderRadius: 10,
    marginBottom: 15,
    fontSize: 16,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  button: {
    backgroundColor: Colors.tint,
    padding: 16,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 10,
    marginBottom: 10,
  },
  buttonText: {
    color: Colors.background,
    fontWeight: 'bold',
    fontSize: 16,
  },
  linkText: {
    color: Colors.yellow,
    textAlign: 'center',
    marginTop: 20,
    fontWeight: 'bold',
  },
});