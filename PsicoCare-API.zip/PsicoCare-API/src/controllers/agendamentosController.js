// Importa o objeto de conexão com o banco de dados MySQL configurado no arquivo db.js
const db = require('../config/db');

/**
 * Função listar
 * Recupera todos os agendamentos do banco de dados do PsicoCare e retorna como resposta JSON.
 * @param {Object} req - Objeto de requisição do Express
 * @param {Object} res - Objeto de resposta do Express
 */
exports.listar = (req, res) => {
  const { usuarioId } = req.query;
  let sql = 'SELECT * FROM agendamentos';
  let params = [];
  if (usuarioId) {
    sql += ' WHERE usuario_id = ?';
    params.push(usuarioId);
  }
  db.query(sql, params, (err, results) => {
    if (err) {
      return res.status(500).json({ erro: err.message });
    }
    res.json(results);
  });
};